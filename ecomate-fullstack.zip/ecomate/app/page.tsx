import Nav from '@/components/landing/Nav'
import Hero from '@/components/landing/Hero'
import Partners from '@/components/landing/Partners'
import Reviews from '@/components/landing/Reviews'
import { Integrations, Features, HowItWorks, DashboardPreview, AISection, Pricing, CTA, Footer } from '@/components/landing/Sections'
import { createClient } from '@/lib/supabase/server'

export default async function HomePage() {
  const supabase = createClient()

  const [{ data: reviews }, { data: partners }] = await Promise.all([
    supabase.from('reviews').select('*').eq('is_approved', true).order('created_at', { ascending: false }).limit(9),
    supabase.from('partners').select('*').order('row_num').order('sort_order'),
  ])

  return (
    <main>
      <Nav />
      <Hero />
      <Integrations />
      <Partners partners={partners || []} />
      <Features />
      <HowItWorks />
      <DashboardPreview />
      <AISection />
      <Pricing />
      <Reviews reviews={reviews || []} />
      <CTA />
      <Footer />
    </main>
  )
}
